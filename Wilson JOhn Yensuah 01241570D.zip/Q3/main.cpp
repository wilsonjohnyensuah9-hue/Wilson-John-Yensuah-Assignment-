#include <iostream>
#include <vector>

double calculateAverage(const std::vector<int>& numbers) {
    
    if (numbers.empty()) {
        return 0.0;
    }
    
    int sum = 0;
    
    for (int num : numbers) {
        sum += num;
    }
    
    return static_cast<double>(sum) / numbers.size();
}

int main() {

    std::vector<int> numbers1 = {18, 82, 83, 34, 55};
    double average1 = calculateAverage(numbers1);
    std::cout << "Average of {18, 82, 83, 34, 55} is: " << average1 << std::endl;
    
    std::vector<int> numbers2 = {15, 28, 90};
    double average2 = calculateAverage(numbers2);
    std::cout << "Average of {15, 28, 90} is: " << average2 << std::endl;
    
    std::vector<int> numbers3 = {11};
    double average3 = calculateAverage(numbers3);
    std::cout << "Average of empty list is: " << average3 << std::endl;
    
    std::vector<int> numbers4 = {42};
    double average4 = calculateAverage(numbers4);
    std::cout << "Average of {42} is: " << average4 << std::endl;
    
    return 0;
}